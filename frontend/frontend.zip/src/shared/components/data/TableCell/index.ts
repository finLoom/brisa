// frontend/src/shared/components/data/TableCell/index.ts
export { default as AssigneeCell } from './AssigneeCell';
export { default as CommentCell } from './CommentCell';
export { default as DateCell } from './DateCell';
export { default as StatusCell } from './StatusCell';
export { default as TitleCell } from './TitleCell';